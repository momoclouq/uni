/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_1;

import java.util.Scanner;

/**
 *
 * @author cis2mye
 */
public class Assignment_1 {
    /**
     * @param args the command line arguments
     */
    
    private static void getInfo(Student[] list, int numberOfStudent, Scanner scanner){
        String input;
        int studentNumber;
        String givenName;
        String familyName;
        int count = 0;
        
        for (int i = 0; i < numberOfStudent; i++){
            System.out.print("Enter student Info here:");
            input = scanner.nextLine();
        
            //extract the information
            /////////////////////////
            
            //get the startpoint/endpoint for student number
            int startpoint = 0, endpoint;
            endpoint = input.indexOf(" ", startpoint);
            
            //get the student number using parseint
            studentNumber = Integer.parseInt(input.substring(startpoint, endpoint));
            
            //get the startpoint/endpoint for given name
            startpoint = endpoint + 1;  // fix the start point
            endpoint = input.indexOf(" ", startpoint);  //find the next end point
       
            //get the given name
            givenName = input.substring(startpoint, endpoint);
            
            //get the startpoint/endpoint for familyname
            startpoint = endpoint+1;
            endpoint = input.length();
            
            //get the familyanme
            familyName = input.substring(startpoint, endpoint);
            ////////////////////////
            
            list[count] = new Student(givenName, familyName, studentNumber); //add the new student to the list
            count++;
        }
    }
    
    private static void changeOrExit(Student[] list, Scanner scanner){
        String input;
        int studentNumber;
        String givenName;
        String familyName;
        
        do {
            System.out.println("Student number and new given/family name?");
            input = scanner.nextLine();
            
            //extract the information
            /////////////////////////
            //get the startpoint/endpoint for student number
            int startpoint = 0, endpoint;
            endpoint = input.indexOf(" ", startpoint);
            if (endpoint < 0) {     //check if the input is just a negative number
                System.out.println("Bye!");
                break;
            }
            //check if the student number is negative
             studentNumber = Integer.parseInt(input.substring(startpoint, endpoint));
             if (studentNumber < 0) {
                 System.out.println("Bye!");
                 break;
             }
           
            //get the startpoint/endpoint for given name
            startpoint = endpoint + 1;  // fix the start point
            endpoint = input.indexOf(" ", startpoint);  //find the next end point
       
            //get the given name
            givenName = input.substring(startpoint, endpoint);
            
            //get the startpoint/endpoint for familyname
            startpoint = endpoint+1;
            endpoint = input.length();
            
            //get the familyanme
            familyName = input.substring(startpoint, endpoint);
            ////////////////////////
            
            //search the student number in the list
            boolean found = false;
            
            for (Student student : list){
                if(student.getStudentnumber() == studentNumber) {
                    student.setgivenN(givenName);
                    student.setfamilyN(familyName);
                    found = true;
                    break;
                }
            }
            
            //print the list
            printList(list);
            
            if (found == false) System.out.println("Cannot find the student number!");
        } while (true);
    }
    
    public static void printList(Student[] list){
        System.out.println("The group is now contains: ");
        for (Student student : list){
            System.out.println(student);
        }
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        int numberOfStudent;
        Scanner scanner = new Scanner(System.in);
        
        //get the number of group size
        do {
            System.out.println("Please enter the group size: ");
            numberOfStudent = Integer.parseInt(scanner.nextLine());
            if (numberOfStudent > 0) break;
        } while (true);
        
        //get the information of the students
        System.out.println("For the student information, please enter them all in a line, with spaces between!");
        System.out.println("Format: studentnumber-firstname-lastname. Example: \"42 tom vassen\"");
        Student[] list = new Student[numberOfStudent]; //create an array(list) of students
        
        //get the list input
        getInfo(list, numberOfStudent, scanner);
        
        //print all students
        printList(list);
        
        //Loop for changing the students
        changeOrExit(list, scanner);
    }
    
}
