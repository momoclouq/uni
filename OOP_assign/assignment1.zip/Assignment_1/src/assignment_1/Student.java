/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_1;

/**
 *
 * @author cis2mye
 */
public class Student {
    private String givenName;
    private String familyName;
    private int studentNumber;
    
    public Student(String givenName, String familyName, int studentNumber){
        this.givenName = givenName;
        this.familyName = familyName;
        this.studentNumber = studentNumber;
    }
    
    public Student(){       //constructor for array
        this.givenName = "?";
        this.familyName = "?";
        this.studentNumber = 0;
    }
    
    public String getgivenN(){  //get the given name
        return givenName;
    }
    
    public String getfamilyN(){ //get the family name
        return familyName;
    }
    
    public void setgivenN(String newname){  //setter for given name
        this.givenName = newname;
    }
    
    public void setfamilyN(String newname){    //setter for family name
        this.familyName = newname;
    }
    
    public int getStudentnumber(){  
        return studentNumber;
    }
    
    public void setStudentnumber(int number){
       this.studentNumber = number;
    }
    
    @Override
    public String toString(){
        return givenName + " " + familyName +", s" + studentNumber;
    }
}
